import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { WalletsService } from '../../../services/wallets.service';

@Component({
  selector: 'app-update-wallet',
  templateUrl: './update-wallet.component.html',
  styleUrl: './update-wallet.component.css',
})
export class UpdateWalletComponent {
  updateform: FormGroup;

  constructor(
    private route: Router,
    private walletService: WalletsService,
    formBuilder: FormBuilder
  ) {
    this.updateform = formBuilder.group({
      name: [''],
      accountNumber: [''],
      description: [''],
      currentBalance: [''],
    });
  }
  handleSubmit() {}
}
