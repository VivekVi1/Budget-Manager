import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { WalletsService } from '../../../services/wallets.service';

@Component({
  selector: 'app-create-wallet',
  templateUrl: './create-wallet.component.html',
  styleUrl: './create-wallet.component.css',
})
export class CreateWalletComponent {
  createWalletForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private walletService: WalletsService
  ) {
    this.createWalletForm = this.formBuilder.group({
      name: ['', Validators.required],
      accountNumber: ['', Validators.required],
      description: [''],
      currentBalance: ['', Validators.required],
    });
  }

  submitHandler() {
    this.walletService.createWallet(this.createWalletForm.value).subscribe({
      next: (response) => {
        console.log('Success', response);
        this.router.navigate(['/dashboard']);
      },
      error: (err) => console.log('Cannot post wallet data', err),
    });
  }
}
