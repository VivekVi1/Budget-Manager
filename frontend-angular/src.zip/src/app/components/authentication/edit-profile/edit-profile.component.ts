import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrl: './edit-profile.component.css',
})
export class EditProfileComponent {
  editUser: FormGroup;
  constructor(private router: Router, formBuilder: FormBuilder) {
    this.editUser = formBuilder.group({
      name: [''],
      email: [''],
      password: [''],
    });
  }
  
  updateUser() {
    // console.log(this.model);
  }
}
