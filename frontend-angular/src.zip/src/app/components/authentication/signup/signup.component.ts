import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../services/authentication.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
})
export class SignupComponent {
  signupForm: FormGroup;

  constructor(
    private router: Router,
    formBuilder: FormBuilder,
    private authService: AuthenticationService
  ) {
    this.signupForm = formBuilder.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  handleSubmit() {
    if (this.signupForm.valid) {
      this.authService.registerUser(this.signupForm.value).subscribe({
        next: (response) => console.log(response),
        error: (e) => console.error(e),
        complete: () => console.info('complete'),
      });
    } else {
      console.log('Form is Invalid');
    }
  }
}
