import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthenticationService } from '../../../services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(
    private router: Router,
    formBuilder: FormBuilder,
    private authService: AuthenticationService
  ) {
    this.loginForm = formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      console.log(this.loginForm);
      this.authService.loginUser(this.loginForm.value).subscribe({
        next: (response) => {
          console.log(response);
          localStorage.setItem('token', response.jwtToken);
          this.router.navigateByUrl('/dashboard');
        },
        error: (e) => console.error(e),
        complete: () => console.info('complete'),
      });
    } else {
      console.log('Form is Invalid');
      alert('Form is Invalid');
    }
  }
}
