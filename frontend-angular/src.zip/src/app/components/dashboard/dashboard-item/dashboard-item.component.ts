import { Component, Input, OnInit } from '@angular/core';
import { WalletsService } from '../../../services/wallets.service';

interface Wallet {
  id: number;
  name: string;
  accountNumber: number;
  description: String;
  currentBalance: number;
}
@Component({
  selector: 'app-dashboard-item',
  templateUrl: './dashboard-item.component.html',
  styleUrl: './dashboard-item.component.css',
})
export class DashboardItemComponent implements OnInit {
  @Input() wallet: any;

  constructor(private walletService: WalletsService) {}

  ngOnInit(): void {
    console.log(this.wallet);
  }

  deleteWallet(): void {
    if (confirm('Are you sure you want to delete this wallet?')) {
      this.walletService.deleteWallet(this.wallet.id).subscribe({
        next: (res) => {
          console.log(res);
          if (res.status === 200) {
            console.log(`Deleting wallet with ID: ${this.wallet.id}`);
          }
        },
        error: (e) => console.log(e),
      });
    }
  }
}
