import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-transaction',
  templateUrl: './edit-transaction.component.html',
  styleUrl: './edit-transaction.component.css',
})
export class EditTransactionComponent {
  editTransactionForm: FormGroup;
  walletId: any;
  id: any;
  transaction: any = {};

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.editTransactionForm = this.formBuilder.group({
      amount: [''],
      description: [''],
      transactionDate: [''],
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.walletId = params.get('walletId');
    });
    // this.fetchTransactionData();
  }

  changeHandler(fieldName: string, event: any): void {
    this.transaction[fieldName] = event.target.value;
  }

  handleSubmit(): void {}
}
