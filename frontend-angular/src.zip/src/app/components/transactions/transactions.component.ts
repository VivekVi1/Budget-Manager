import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TransactionsService } from '../../services/transactions.service';
import { WalletsService } from '../../services/wallets.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css'],
})
export class TransactionComponent implements OnInit {
  walletId: any;
  transactions: any[] = [];
  wallet: any = {};
  totalSpent: number = 0;
  remainingBalance: number = 0;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private transactionsService: TransactionsService,
    private walletService: WalletsService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.walletId = params.get('walletId');
    });
    console.log(this.walletId);
    this.getTransactions();
  }

  getTransactions(): void {
    this.transactionsService.getTransactions(this.walletId).subscribe({
      next: (res) => {
        console.log(res), (this.transactions = res);
      },
      error: (e) => console.log(e),
    });
  }

  deleteTransaction(transactionId: number): void {}
}
