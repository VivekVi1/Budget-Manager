import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TransactionsService } from '../../../services/transactions.service';

@Component({
  selector: 'app-add-transaction',
  templateUrl: './add-transaction.component.html',
  styleUrls: ['./add-transaction.component.css'],
})
export class AddTransactionComponent implements OnInit {
  transactionForm: FormGroup;
  walletId: any;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private transactionsService: TransactionsService
  ) {
    this.transactionForm = this.formBuilder.group({
      amount: ['', Validators.required],
      description: ['', Validators.required],
      transactionDate: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.walletId = params.get('walletId');
    });
    console.log(this.walletId);
  }

  onSubmit(): void {
    console.log(this.transactionForm.value);
    this.transactionsService
      .addTransaction(this.transactionForm.value, this.walletId)
      .subscribe({
        next: (res) => {
          console.log(res), alert('Transactions Added');
        },
        error: (e) => console.log(e),
      });
  }
}
