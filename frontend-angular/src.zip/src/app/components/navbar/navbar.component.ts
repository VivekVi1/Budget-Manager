import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
})
export class NavbarComponent {
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit(): void {
    // this.userService.getUser().subscribe({
    //   next: (response) => console.log(response),
    //   error: (e) => console.error(e),
    //   complete: () => console.info('complete'),
    // });
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}
